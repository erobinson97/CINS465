#read lines from standard input
varIN = [x.strip() for x in input().split(',')]

for x in varIN:
    if(x != ""):
        print(x)